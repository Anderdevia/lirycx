﻿namespace Karaoke.Models
{
    public class Modulo
    {
        public int IdModulo { get; set; }

        public string Nombre { get; set; } = string.Empty;

        public string? Icono { get; set; }

        public int Orden { get; set; }

        public string? Ruta { get; set; }

        public bool Activo { get; set; }

        public ICollection<Submodulo> Submodulos { get; set; }
            = new List<Submodulo>();
    }
}
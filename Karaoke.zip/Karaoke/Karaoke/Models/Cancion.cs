﻿namespace Karaoke.Models
{
    public class Cancion
    {
        public int IdCancion { get; set; }

        public int IdSubModulo { get; set; }

        public string Titulo { get; set; } = string.Empty;

        public string? Artista { get; set; }

        public string ArchivoAudio { get; set; } = string.Empty;

        public string? ArchivoLrc { get; set; }

        public string? Imagenpr { get; set; }
        public string? Imagen { get; set; }

        /// <summary>
        /// Duración del audio en segundos.
        /// </summary>
        public int DuracionSegundos { get; set; }

        /// <summary>
        /// Indica si la canción fue marcada como favorita.
        /// </summary>
        public bool Favorita { get; set; }

        /// <summary>
        /// Cantidad de veces que se ha reproducido.
        /// </summary>
        public int CantidadReproducciones { get; set; }

        /// <summary>
        /// Nivel de dificultad de la canción.
        /// </summary>
        public short Nivel { get; set; }

        public int Orden { get; set; }

        public bool Activo { get; set; }

        public Submodulo? SubModulo { get; set; }

        /// <summary>
        /// Devuelve la duración en formato mm:ss.
        /// No se almacena en la base de datos.
        /// </summary>
        public string DuracionTexto =>
            TimeSpan.FromSeconds(DuracionSegundos)
                    .ToString(@"mm\:ss");
    }

 
}
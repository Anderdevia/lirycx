﻿namespace Karaoke.Models
{
    public class Cancion
    {
        public int IdCancion { get; set; }

        public int IdSubmodulo { get; set; }

        public string Titulo { get; set; } = string.Empty;

        public string? Artista { get; set; }

        public string ArchivoAudio { get; set; } = string.Empty;

        public string? ArchivoLrc { get; set; }

        public string? Imagen { get; set; }

        public int Orden { get; set; }

        public bool Activo { get; set; }

        public Submodulo Submodulo { get; set; } = null!;
    }
}
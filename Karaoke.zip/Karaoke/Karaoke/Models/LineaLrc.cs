﻿namespace Karaoke.Models
{
    public class LineaLrc
    {
        public double Tiempo { get; set; }

        public string Texto { get; set; } = string.Empty;

        public string Traduccion { get; set; } = string.Empty;
    }
}
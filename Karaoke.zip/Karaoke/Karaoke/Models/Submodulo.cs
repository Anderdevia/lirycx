﻿namespace Karaoke.Models
{
    public class Submodulo
    {
        public int IdSubmodulo { get; set; }

        public int IdModulo { get; set; }

        public string Nombre { get; set; } = string.Empty;

        public string? Icono { get; set; }

        public int Orden { get; set; }

        public string Ruta { get; set; } = string.Empty;

        public bool Activo { get; set; }

        public Modulo Modulo { get; set; } = null!;

        // Relación con Canciones
        public ICollection<Cancion> Canciones { get; set; }
            = new List<Cancion>();
    }
}
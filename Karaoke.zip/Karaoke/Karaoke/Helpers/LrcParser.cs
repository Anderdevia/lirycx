﻿using Karaoke.Models;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Karaoke.Helpers
{
    public static class LrcParser
    {
        private static readonly Regex RegexLinea =
            new(@"\[(\d{2}):(\d{2}(?:\.\d+)?)\](.*)");

        public static List<LineaLrc> Parse(string contenido)
        {
            var lineas = new List<LineaLrc>();

            foreach (var linea in contenido.Split('\n'))
            {
                var match = RegexLinea.Match(linea.Trim());

                if (!match.Success)
                {
                    continue;
                }

                int minutos =
                    int.Parse(match.Groups[1].Value);

                double segundos =
                    double.Parse(
                        match.Groups[2].Value,
                        CultureInfo.InvariantCulture
                    );

                string texto =
                    match.Groups[3].Value.Trim();

                double tiempoTotal =
                    (minutos * 60) + segundos;

                lineas.Add(new LineaLrc
                {
                    Tiempo = tiempoTotal,
                    Texto = texto
                });
            }

            return lineas
                .OrderBy(x => x.Tiempo)
                .ToList();
        }
    }
}
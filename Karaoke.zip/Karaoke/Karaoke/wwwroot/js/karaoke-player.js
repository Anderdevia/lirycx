﻿window.karaokePlayer = {

    iniciar: function (audioId, lineas) {

        const audio =
            document.getElementById(audioId);

        const contenedorTraduccion =
            document.getElementById("contenedorTraduccion");

        const textoTraduccion =
            document.getElementById("textoTraduccion");

        // =====================================
        // ARRASTRAR CUADRO DE TRADUCCIÓN
        // =====================================

        let arrastrandoTraduccion = false;

        let desplazamientoX = 0;
        let desplazamientoY = 0;


        // =====================================
        // COMENZAR ARRASTRE
        // =====================================

        contenedorTraduccion.addEventListener(
            "pointerdown",
            function (evento) {

                arrastrandoTraduccion = true;

                const rect =
                    contenedorTraduccion
                        .getBoundingClientRect();


                // Guardar distancia desde el punto
                // pulsado hasta la esquina del cuadro

                desplazamientoX =
                    evento.clientX - rect.left;

                desplazamientoY =
                    evento.clientY - rect.top;


                // IMPORTANTE:
                // eliminar translate(-50%)

                contenedorTraduccion.style.transform =
                    "none";


                // Mantener captura del puntero

                contenedorTraduccion.setPointerCapture(
                    evento.pointerId
                );


                contenedorTraduccion.classList.add(
                    "arrastrando"
                );

            }
        );


        // =====================================
        // MOVER CUADRO
        // =====================================

        contenedorTraduccion.addEventListener(
            "pointermove",
            function (evento) {

                if (!arrastrandoTraduccion) {
                    return;
                }


                const anchoCuadro =
                    contenedorTraduccion.offsetWidth;

                const altoCuadro =
                    contenedorTraduccion.offsetHeight;


                // =====================================
                // CALCULAR NUEVA POSICIÓN
                // =====================================

                let nuevaX =
                    evento.clientX -
                    desplazamientoX;

                let nuevaY =
                    evento.clientY -
                    desplazamientoY;


                // =====================================
                // EVITAR SALIR DE LA PANTALLA
                // =====================================

                nuevaX =
                    Math.max(
                        5,
                        Math.min(
                            nuevaX,
                            window.innerWidth -
                            anchoCuadro -
                            5
                        )
                    );


                nuevaY =
                    Math.max(
                        5,
                        Math.min(
                            nuevaY,
                            window.innerHeight -
                            altoCuadro -
                            5
                        )
                    );


                // =====================================
                // MOVER CUADRO
                // =====================================

                contenedorTraduccion.style.left =
                    `${nuevaX}px`;

                contenedorTraduccion.style.top =
                    `${nuevaY}px`;

            }
        );


        // =====================================
        // TERMINAR ARRASTRE
        // =====================================

        contenedorTraduccion.addEventListener(
            "pointerup",
            function (evento) {

                arrastrandoTraduccion = false;


                contenedorTraduccion.classList.remove(
                    "arrastrando"
                );


                if (
                    contenedorTraduccion.hasPointerCapture(
                        evento.pointerId
                    )
                ) {

                    contenedorTraduccion.releasePointerCapture(
                        evento.pointerId
                    );

                }

            }
        );


        // =====================================
        // CANCELAR ARRASTRE
        // =====================================

        contenedorTraduccion.addEventListener(
            "pointercancel",
            function () {

                arrastrandoTraduccion = false;

                contenedorTraduccion.classList.remove(
                    "arrastrando"
                );

            }
        );

        const contenedor =
            document.querySelector(".letra-container");

        const btnPlay =
            document.getElementById("btnPlay");

        const btnVolumen =
            document.getElementById("btnVolumen");

        const barraProgreso =
            document.getElementById("barraProgreso");

        const progresoActual =
            document.getElementById("progresoActual");

        const tiempoActual =
            document.getElementById("tiempoActual");

        const duracionTotal =
            document.getElementById("duracionTotal");


        const controlVolumen =
            document.querySelector(".control-volumen");

        const contenedorVolumen =
            document.getElementById("contenedorVolumen");

        const barraVolumen =
            document.getElementById("barraVolumen");

        const controlVelocidad =
            document.querySelector(".control-velocidad");

        const btnVelocidad =
            document.getElementById("btnVelocidad");

        const contenedorVelocidad =
            document.getElementById("contenedorVelocidad");

        const opcionesVelocidad =
            document.querySelectorAll(".opcion-velocidad");

        const canvas =
            document.getElementById("visualizadorAudio");


        const elementos =
            contenedor.querySelectorAll(".linea-letra");


        if (canvas) {
            iniciarVisualizadorAudio(audio, canvas);
        }


        if (!audio || !contenedor) {
            return;
        }


        let indiceAnterior = -1;


        // =====================================
        // SELECCIONAR LÍNEA DEL KARAOKE
        // COLOCAR AQUÍ
        // =====================================

        elementos.forEach((elemento, indice) => {

            elemento.addEventListener(
                "click",
                async function () {

                    const tiempoLinea =
                        lineas[indice].tiempo ??
                        lineas[indice].Tiempo;

                    if (
                        tiempoLinea === undefined ||
                        tiempoLinea === null
                    ) {
                        return;
                    }


                    // Cambiar tiempo del audio

                    audio.currentTime = tiempoLinea;
                    audio.play();

                    // Forzar actualización de la línea

                    indiceAnterior = -1;


                    // Actualizar letra

                    actualizarLetra();


                    // Actualizar barra de progreso

                    actualizarProgreso();


                    // Reproducir automáticamente

                    try {

                        await audio.play();

                    }
                    catch (error) {

                        console.error(
                            "Error reproduciendo audio:",
                            error
                        );

                    }

                }
            );

        });



        // =====================================
        // SELECCIONAR LÍNEA DEL KARAOKE
        // =====================================

        // elementos.forEach((elemento, indice) => {

        //     elemento.addEventListener(
        //         "click",
        //         function () {

        //             const tiempoLinea =
        //                 lineas[indice].tiempo ??
        //                 lineas[indice].Tiempo;

        //             if (
        //                 tiempoLinea === undefined ||
        //                 tiempoLinea === null
        //             ) {
        //                 return;
        //             }


        //             // =====================================
        //             // CAMBIAR POSICIÓN DEL AUDIO
        //             // =====================================

        //             audio.currentTime = tiempoLinea;

        //             audio.play();
        //             // =====================================
        //             // ACTUALIZAR LETRA INMEDIATAMENTE
        //             // =====================================

        //             actualizarLetra();


        //             // =====================================
        //             // ACTUALIZAR BARRA DE PROGRESO
        //             // =====================================

        //             actualizarProgreso();

        //         }
        //     );

        // });

        // =====================================
        // MOSTRAR / OCULTAR VELOCIDADES
        // =====================================

        btnVelocidad.addEventListener(
            "click",
            function (evento) {

                evento.stopPropagation();

                contenedorVelocidad
                    .classList
                    .toggle("visible");

                // Cerrar volumen si está abierto

                contenedorVolumen
                    .classList
                    .remove("visible");
            }
        );


        // =====================================
        // SELECCIONAR VELOCIDAD
        // =====================================

        opcionesVelocidad.forEach(opcion => {

            opcion.addEventListener(
                "click",
                function (evento) {

                    evento.stopPropagation();

                    const velocidad =
                        parseFloat(
                            opcion.dataset.velocidad
                        );

                    // Cambiar velocidad del audio

                    audio.playbackRate = velocidad;


                    // Actualizar texto del botón

                    btnVelocidad.textContent =
                        `${velocidad}x`;


                    // Quitar selección anterior

                    opcionesVelocidad.forEach(item => {

                        item.classList.remove("activa");

                    });


                    // Marcar selección actual

                    opcion.classList.add("activa");


                    // Cerrar menú

                    contenedorVelocidad
                        .classList
                        .remove("visible");

                }
            );

        });


        // =====================================
        // EVITAR CERRAR AL PULSAR EL CONTROL
        // =====================================

        controlVelocidad.addEventListener(
            "click",
            function (evento) {

                evento.stopPropagation();

            }
        );


        // =====================================
        // PLAY / PAUSA
        // =====================================

        btnPlay.addEventListener("click", function () {

            if (audio.paused) {

                audio.play();

            }
            else {

                audio.pause();

            }

        });


        audio.addEventListener("play", function () {

            btnPlay.textContent = "⏸";

        });


        audio.addEventListener("pause", function () {

            btnPlay.textContent = "▶";

        });


        // =====================================
        // DURACIÓN
        // =====================================

        audio.addEventListener(
            "loadedmetadata",
            function () {

                duracionTotal.textContent =
                    formatearTiempo(audio.duration);

            }
        );


        // =====================================
        // ACTUALIZACIÓN DEL AUDIO
        // =====================================

        audio.addEventListener(
            "timeupdate",
            function () {

                actualizarProgreso();

                actualizarLetra();

            }
        );

        function actualizarTraduccion(indiceActivo) {

            if (
                !contenedorTraduccion ||
                !textoTraduccion ||
                indiceActivo < 0 ||
                indiceActivo >= lineas.length
            ) {
                contenedorTraduccion
                    ?.classList
                    .remove("visible");

                return;
            }


            const traduccion =
                lineas[indiceActivo].traduccion ?? "";


            if (!traduccion.trim()) {

                textoTraduccion.textContent = "";

                contenedorTraduccion
                    .classList
                    .remove("visible");

                return;
            }


            // ÚNICAMENTE CAMBIAR EL TEXTO
            // NO CAMBIAR LA POSICIÓN

            textoTraduccion.textContent =
                traduccion;


            contenedorTraduccion
                .classList
                .add("visible");
        }
        function actualizarProgreso() {

            if (!audio.duration) {
                return;
            }


            // Si el usuario está arrastrando,
            // timeupdate no modifica la barra

            if (arrastrandoProgreso) {
                return;
            }


            const porcentaje =
                (audio.currentTime / audio.duration)
                * 100;


            progresoActual.style.width =
                `${porcentaje}%`;


            tiempoActual.textContent =
                formatearTiempo(audio.currentTime);
        }

        barraProgreso.addEventListener(
            "pointerdown",
            function (evento) {

                arrastrandoProgreso = true;

                barraProgreso.classList.add(
                    "arrastrando"
                );

                barraProgreso.setPointerCapture(
                    evento.pointerId
                );

                cambiarPosicionAudio(evento);
            }
        );

        // =====================================
        // ARRASTRAR BARRA DE PROGRESO
        // =====================================

        let arrastrandoProgreso = false;


        function cambiarPosicionAudio(evento) {

            if (!audio.duration) {
                return;
            }

            const rect =
                barraProgreso.getBoundingClientRect();

            let posicionX =
                evento.clientX - rect.left;


            // Evitar salir de los límites de la barra

            posicionX =
                Math.max(
                    0,
                    Math.min(posicionX, rect.width)
                );


            const porcentaje =
                posicionX / rect.width;


            // Actualizar visualmente la barra inmediatamente

            progresoActual.style.width =
                `${porcentaje * 100}%`;


            // Actualizar tiempo mostrado

            const nuevoTiempo =
                porcentaje * audio.duration;


            tiempoActual.textContent =
                formatearTiempo(nuevoTiempo);


            // Mover el audio

            audio.currentTime =
                nuevoTiempo;
        }


 


        // =====================================
        // MOVER BARRA
        // =====================================

        barraProgreso.addEventListener(
            "pointermove",
            function (evento) {

                if (!arrastrandoProgreso) {
                    return;
                }

                cambiarPosicionAudio(evento);
            }
        );


        // =====================================
        // TERMINAR ARRASTRE
        // =====================================

        barraProgreso.addEventListener(
            "pointerup",
            function (evento) {

                arrastrandoProgreso = false;

                barraProgreso.classList.remove(
                    "arrastrando"
                );

                barraProgreso.releasePointerCapture(
                    evento.pointerId
                );
            }
        );


        // =====================================
        // CANCELAR ARRASTRE
        // =====================================

        barraProgreso.addEventListener(
            "pointercancel",
            function () {

                arrastrandoProgreso = false;
            }
        );

        // =====================================
        // CAMBIAR POSICIÓN DEL AUDIO
        // =====================================

        barraProgreso.addEventListener(
            "click",
            function (evento) {

                const rect =
                    barraProgreso
                        .getBoundingClientRect();

                const posicion =
                    evento.clientX - rect.left;

                const porcentaje =
                    posicion / rect.width;

                audio.currentTime =
                    porcentaje * audio.duration;

            }
        );


        // =====================================
        // VOLUMEN
        // =====================================

        // =====================================
        // MOSTRAR / OCULTAR CONTROL DE VOLUMEN
        // =====================================

        btnVolumen.addEventListener(
            "click",
            function (evento) {

                evento.stopPropagation();

                contenedorVolumen
                    .classList
                    .toggle("visible");
            }
        );


        // =====================================
        // CAMBIAR VOLUMEN
        // =====================================

        barraVolumen.addEventListener(
            "input",
            function () {

                const volumen =
                    parseFloat(barraVolumen.value);

                audio.volume = volumen;

                audio.muted = volumen === 0;

                actualizarIconoVolumen();
            }
        );


        // =====================================
        // ACTUALIZAR ICONO
        // =====================================

        function actualizarIconoVolumen() {

            if (audio.muted || audio.volume === 0) {

                btnVolumen.textContent = "🔇";

            }
            else if (audio.volume < 0.5) {

                btnVolumen.textContent = "🔉";

            }
            else {

                btnVolumen.textContent = "🔊";
            }
        }


        // =====================================
        // EVITAR CERRAR AL USAR LA BARRA
        // =====================================

        controlVolumen.addEventListener(
            "click",
            function (evento) {

                evento.stopPropagation();
            }
        );


        // =====================================
        // CERRAR AL PULSAR FUERA
        // =====================================

        document.addEventListener(
            "click",
            function () {

                contenedorVolumen
                    .classList
                    .remove("visible");

                contenedorVelocidad
                    .classList
                    .remove("visible");
            }
        );


        // =====================================
        // SINCRONIZACIÓN DEL KARAOKE
        // =====================================

        function actualizarLetra() {

            const tiempo = audio.currentTime;

            let indiceActivo = -1;

            for (let i = 0; i < lineas.length; i++) {

                const tiempoLinea =
                    lineas[i].tiempo ??
                    lineas[i].Tiempo;

                if (tiempo >= tiempoLinea) {

                    indiceActivo = i;

                }
                else {

                    break;

                }
            }


            if (indiceActivo === indiceAnterior) {
                return;
            }


            indiceAnterior = indiceActivo;
            setTimeout(
                function () {

                    actualizarTraduccion(
                        indiceActivo
                    );

                },
                300
            );

            elementos.forEach(
                (elemento, indice) => {

                    elemento.classList.remove(
                        "activa",
                        "anterior",
                        "siguiente"
                    );


                    if (indice < indiceActivo) {

                        elemento
                            .classList
                            .add("anterior");

                    }
                    else if (
                        indice === indiceActivo
                    ) {

                        elemento
                            .classList
                            .add("activa");

                    }
                    else {

                        elemento
                            .classList
                            .add("siguiente");

                    }

                }
            );


            if (indiceActivo >= 0) {

                centrarLinea(
                    contenedor,
                    elementos[indiceActivo]
                );

            }


        }

    }

};


// =====================================
// MOSTRAR DURACIÓN TOTAL DEL AUDIO
// =====================================

// =====================================
// DURACIÓN TOTAL DEL AUDIO
// =====================================

function actualizarDuracionTotal() {

    const duracion = audio.duration;

    console.log(
        "Duración:",
        duracion,
        "ReadyState:",
        audio.readyState
    );

    if (
        typeof duracion === "number" &&
        isFinite(duracion) &&
        duracion > 0
    ) {
        duracionTotal.textContent =
            formatearTiempo(duracion);

        return true;
    }

    return false;
}


// =====================================
// EVENTOS DE CARGA DEL AUDIO
// =====================================

audio.addEventListener(
    "loadedmetadata",
    actualizarDuracionTotal
);

audio.addEventListener(
    "loadeddata",
    actualizarDuracionTotal
);

audio.addEventListener(
    "canplay",
    actualizarDuracionTotal
);

audio.addEventListener(
    "durationchange",
    actualizarDuracionTotal
);


// =====================================
// COMPROBAR INMEDIATAMENTE
// =====================================

actualizarDuracionTotal();


// =====================================
// FORZAR CARGA DE METADATOS
// =====================================

if (audio.readyState === 0) {
    audio.load();
}



// Por si los metadatos ya estaban cargados
// antes de iniciar el JavaScript

if (audio.readyState >= 1) {
    actualizarDuracionTotal();
}

function iniciarVisualizadorAudio(audio, canvas) {

    const AudioContext =
        window.AudioContext ||
        window.webkitAudioContext;

    const audioContext =
        new AudioContext();

    const analyser =
        audioContext.createAnalyser();

    analyser.fftSize = 256;

    analyser.smoothingTimeConstant = 0.85;

    const source =
        audioContext.createMediaElementSource(audio);

    source.connect(analyser);

    analyser.connect(audioContext.destination);

    const bufferLength =
        analyser.frequencyBinCount;

    const dataArray =
        new Uint8Array(bufferLength);

    const ctx =
        canvas.getContext("2d");


    // =====================================
    // AJUSTAR TAMAÑO DEL CANVAS
    // =====================================

    function ajustarCanvas() {

        const rect =
            canvas.getBoundingClientRect();

        const pixelRatio =
            window.devicePixelRatio || 1;

        canvas.width =
            rect.width * pixelRatio;

        canvas.height =
            rect.height * pixelRatio;

        ctx.setTransform(
            pixelRatio,
            0,
            0,
            pixelRatio,
            0,
            0
        );
    }


    ajustarCanvas();

    window.addEventListener(
        "resize",
        ajustarCanvas
    );


    // =====================================
    // ACTIVAR AUDIO CONTEXT
    // =====================================

    audio.addEventListener(
        "play",
        async function () {

            if (audioContext.state === "suspended") {

                await audioContext.resume();

            }

        }
    );


    // =====================================
    // DIBUJAR ECUALIZADOR
    // =====================================

    function dibujar() {

        // Mantener la animación activa
        requestAnimationFrame(dibujar);


        // =====================================
        // OBTENER FRECUENCIAS DEL AUDIO
        // =====================================

        analyser.getByteFrequencyData(dataArray);


        // =====================================
        // TAMAÑO VISIBLE DEL CANVAS
        // =====================================

        const ancho =
            canvas.clientWidth;

        const alto =
            canvas.clientHeight;


        // =====================================
        // LIMPIAR CANVAS
        // =====================================

        ctx.clearRect(
            0,
            0,
            ancho,
            alto
        );


        // =====================================
        // CONFIGURACIÓN DE LAS BARRAS
        // =====================================

        const cantidadBarras = 45;

        const espacio = 5;

        const anchoBarra = 5;


        // =====================================
        // CALCULAR ANCHO TOTAL
        // =====================================

        const anchoTotal =
            (cantidadBarras * anchoBarra)
            +
            ((cantidadBarras - 1) * espacio);


        // =====================================
        // CALCULAR PUNTO DE INICIO CENTRADO
        // =====================================

        const inicioX =
            (ancho - anchoTotal) / 2;


        // =====================================
        // DIBUJAR BARRAS
        // =====================================

        for (
            let i = 0;
            i < cantidadBarras;
            i++
        ) {

            // Obtener frecuencia correspondiente

            const indiceFrecuencia =
                Math.floor(
                    i *
                    bufferLength /
                    cantidadBarras
                );


            const valor =
                dataArray[indiceFrecuencia];


            const porcentaje =
                valor / 255;


            // =====================================
            // ALTURA DE LA BARRA
            // =====================================

            const alturaBarra =
                Math.max(
                    4,
                    porcentaje * alto * 0.80
                );


            // =====================================
            // POSICIÓN HORIZONTAL CENTRADA
            // =====================================

            const x =
                inicioX
                +
                i * (anchoBarra + espacio);


            // =====================================
            // CENTRAR VERTICALMENTE
            // =====================================

            const y =
                (alto - alturaBarra) / 2;


            // =====================================
            // DEGRADADO
            // =====================================

            const gradient =
                ctx.createLinearGradient(
                    0,
                    y,
                    0,
                    y + alturaBarra
                );


            gradient.addColorStop(
                0,
                "rgba(180, 120, 255, 1)"
            );


            gradient.addColorStop(
                0.5,
                "rgba(100, 160, 255, 0.9)"
            );


            gradient.addColorStop(
                1,
                "rgba(80, 220, 220, 0.7)"
            );


            ctx.fillStyle = gradient;


            // =====================================
            // DIBUJAR BARRA REDONDEADA
            // =====================================

            ctx.beginPath();


            ctx.roundRect(
                x,
                y,
                anchoBarra,
                alturaBarra,
                anchoBarra / 2
            );


            ctx.fill();

        }

    }

    


    dibujar();
}

function centrarLinea(contenedor, linea) {

    const contenedorRect =
        contenedor.getBoundingClientRect();

    const lineaRect =
        linea.getBoundingClientRect();

    const diferencia =
        lineaRect.top
        - contenedorRect.top
        - (contenedor.clientHeight / 2)
        + (lineaRect.height / 2);

    contenedor.scrollTo({

        top:
            contenedor.scrollTop
            + diferencia,

        behavior: "smooth"

    });

}

function formatearTiempo(segundos) {

    if (
        isNaN(segundos) ||
        !isFinite(segundos)
    ) {
        return "0:00";
    }

    const minutos =
        Math.floor(segundos / 60);

    const segundosRestantes =
        Math.floor(segundos % 60);

    return (
        minutos
        + ":"
        + segundosRestantes
            .toString()
            .padStart(2, "0")
    );
}


function centrarLinea(contenedor, linea) {

    const contenedorRect =
        contenedor.getBoundingClientRect();

    const lineaRect =
        linea.getBoundingClientRect();

    const posicionActual =
        contenedor.scrollTop;

    const diferencia =
        lineaRect.top
        - contenedorRect.top
        - (contenedor.clientHeight / 2)
        + (lineaRect.height / 2);

    contenedor.scrollTo({
        top: posicionActual + diferencia,
        behavior: "smooth"
    });
}
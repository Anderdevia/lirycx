﻿using Karaoke.Models;
using Microsoft.EntityFrameworkCore;

namespace Karaoke.Data
{
    public class KaraokeDbContext : DbContext
    {
        public KaraokeDbContext(
            DbContextOptions<KaraokeDbContext> options)
            : base(options)
        {
        }

        // TABLAS
        public DbSet<Modulo> Modulos => Set<Modulo>();

        public DbSet<Submodulo> Submodulos => Set<Submodulo>();

        public DbSet<Cancion> Canciones => Set<Cancion>();


        // CONFIGURACIÓN DE LAS TABLAS
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            // =========================================
            // MODULO
            // =========================================

            modelBuilder.Entity<Modulo>(entity =>
            {
                entity.ToTable("modulo");

                entity.HasKey(x => x.IdModulo);

                entity.Property(x => x.IdModulo)
                    .HasColumnName("id_modulo");

                entity.Property(x => x.Nombre)
                    .HasColumnName("nombre");

                entity.Property(x => x.Icono)
                    .HasColumnName("icono");

                entity.Property(x => x.Orden)
                    .HasColumnName("orden");

                entity.Property(x => x.Ruta)
                    .HasColumnName("ruta");

                entity.Property(x => x.Activo)
                    .HasColumnName("activo");
            });


            // =========================================
            // SUBMODULO
            // =========================================

            modelBuilder.Entity<Submodulo>(entity =>
            {
                entity.ToTable("submodulo");

                entity.HasKey(x => x.IdSubmodulo);

                entity.Property(x => x.IdSubmodulo)
                    .HasColumnName("id_submodulo");

                entity.Property(x => x.IdModulo)
                    .HasColumnName("id_modulo");

                entity.Property(x => x.Nombre)
                    .HasColumnName("nombre");

                entity.Property(x => x.Icono)
                    .HasColumnName("icono");

                entity.Property(x => x.Orden)
                    .HasColumnName("orden");

                entity.Property(x => x.Ruta)
                    .HasColumnName("ruta");

                entity.Property(x => x.Activo)
                    .HasColumnName("activo");


                // RELACIÓN:
                // UN MODULO TIENE MUCHOS SUBMODULOS

                entity.HasOne(x => x.Modulo)
                    .WithMany(x => x.Submodulos)
                    .HasForeignKey(x => x.IdModulo);
            });


            // =========================================
            // CANCION
            // =========================================

            modelBuilder.Entity<Cancion>(entity =>
            {
                entity.ToTable("cancion");

                entity.HasKey(x => x.IdCancion);

                entity.Property(x => x.IdCancion)
                    .HasColumnName("id_cancion");

                entity.Property(x => x.IdSubmodulo)
                    .HasColumnName("id_submodulo");

                entity.Property(x => x.Titulo)
                    .HasColumnName("titulo");

                entity.Property(x => x.Artista)
                    .HasColumnName("artista");

                entity.Property(x => x.ArchivoAudio)
                    .HasColumnName("archivo_audio");

                entity.Property(x => x.ArchivoLrc)
                    .HasColumnName("archivo_lrc");

                entity.Property(x => x.Imagen)
                    .HasColumnName("imagen");

                entity.Property(x => x.Orden)
                    .HasColumnName("orden");

                entity.Property(x => x.Activo)
                    .HasColumnName("activo");


                // RELACIÓN:
                // UN SUBMODULO TIENE MUCHAS CANCIONES

                entity.HasOne(x => x.Submodulo)
                    .WithMany(x => x.Canciones)
                    .HasForeignKey(x => x.IdSubmodulo);
            });
        }
    }
}
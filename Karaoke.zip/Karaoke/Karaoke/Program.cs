using Karaoke.Components;
using Karaoke.Data;
using Karaoke.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);


// ========================================
// BLAZOR
// ========================================

builder.Services
    .AddRazorComponents()
    .AddInteractiveServerComponents();


// ========================================
// POSTGRESQL
// ========================================

builder.Services.AddDbContextFactory<KaraokeDbContext>(options =>
{
    options.UseNpgsql(
        builder.Configuration.GetConnectionString("PostgreSQL")
    );
});


// ========================================
// SERVICIOS
// ========================================

builder.Services.AddScoped<ModuloService>();
builder.Services.AddScoped<CancionService>();


// ========================================
// CONSTRUIR APLICACIÓN
// ========================================

var app = builder.Build();


// ========================================
// MANEJO DE ERRORES
// ========================================

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler(
        "/Error",
        createScopeForErrors: true
    );

    app.UseHsts();
}


app.UseStatusCodePagesWithReExecute(
    "/not-found",
    createScopeForStatusCodePages: true
);


// ========================================
// CARPETA DE AUDIOS
// ========================================

string cancionesPath =
    builder.Configuration["Karaoke:RutaCanciones"]
    ?? throw new InvalidOperationException(
        "No se configuró Karaoke:RutaCanciones"
    );

if (!Directory.Exists(cancionesPath))
{
    throw new DirectoryNotFoundException(
        $"No se encontró la carpeta: {cancionesPath}"
    );
}


app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(cancionesPath),

    RequestPath = "/media"
});


// ========================================
// BLAZOR
// ========================================

app.UseAntiforgery();

app.MapStaticAssets();


app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();


// ========================================
// INICIAR SERVIDOR
// ========================================

// 0.0.0.0 permite acceder desde otros dispositivos
// conectados a la misma red WiFi.

app.Run("http://0.0.0.0:5000");
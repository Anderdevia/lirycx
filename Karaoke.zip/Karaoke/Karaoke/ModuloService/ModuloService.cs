﻿using Karaoke.Data;
using Karaoke.Models;
using Microsoft.EntityFrameworkCore;

namespace Karaoke.Services
{
    public class ModuloService
    {
        private readonly IDbContextFactory<KaraokeDbContext> _dbFactory;

        public ModuloService(
            IDbContextFactory<KaraokeDbContext> dbFactory)
        {
            _dbFactory = dbFactory;
        }


        public async Task<List<Modulo>> ObtenerMenuAsync()
        {
            await using var db =
                await _dbFactory.CreateDbContextAsync();

            return await db.Modulos

                .AsNoTracking()

                .Where(x => x.Activo)

                .Include(x => x.Submodulos
                    .Where(s => s.Activo))

                .OrderBy(x => x.Orden)

                .ToListAsync();
        }
    }
}
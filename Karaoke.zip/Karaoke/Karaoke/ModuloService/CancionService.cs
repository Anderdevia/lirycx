﻿using Karaoke.Data;
using Karaoke.Models;
using Microsoft.EntityFrameworkCore;

namespace Karaoke.Services
{
    public class CancionService
    {
        private readonly IDbContextFactory<KaraokeDbContext> _dbFactory;

        public CancionService(
            IDbContextFactory<KaraokeDbContext> dbFactory)
        {
            _dbFactory = dbFactory;
        }

        public async Task<List<Cancion>> ObtenerPorRutaAsync(
            string modulo,
            string submodulo)
        {
            string ruta = $"/{modulo}/{submodulo}";

            await using var db =
                await _dbFactory.CreateDbContextAsync();

            return await db.Canciones
                .AsNoTracking()
                .Where(x =>
                    x.Activo &&
                    x.SubModulo.Activo &&
                    x.SubModulo.Ruta == ruta)
                .OrderBy(x => x.Orden)
                .ToListAsync();
        }

        public async Task<Cancion?> ObtenerPorIdAsync(
           int idCancion)
        {
            await using var db =
                await _dbFactory.CreateDbContextAsync();

            return await db.Canciones
                .AsNoTracking()
                .FirstOrDefaultAsync(x =>
                    x.IdCancion == idCancion &&
                    x.Activo);
        }
    }
}